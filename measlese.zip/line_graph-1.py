import pandas
import matplotlib.pyplot


def gather_data(index):
    i = 1990
    temp = []
    year = []
    data = []
    read = pandas.read_csv("measles.csv")
    while i != 2017:
        data.append(read[str(i)][index])
        year.append(i)
        i = i + 1
    temp.append(data)
    temp.append(year)
    return temp


def display_chart():
    # read = pandas.read_csv("measles.csv")
    india = gather_data(78)
    pakistan = gather_data(129)
    srilanka = gather_data(13)
    # print(read["Country"][163])
    matplotlib.pyplot.plot(india[1], india[0], label="India")
    matplotlib.pyplot.plot(pakistan[1], pakistan[0], label="Pakistan")
    matplotlib.pyplot.plot(srilanka[1], srilanka[0], label="Bangladesh")
    # matplotlib.pyplot.barh(india[1], india[0])
    # matplotlib.pyplot.barh(pakistan[1], pakistan[0])
    matplotlib.pyplot.legend()
    matplotlib.pyplot.xlabel("Years")
    matplotlib.pyplot.ylabel("Vaccination percentage")
    matplotlib.pyplot.title("Vaccination percentage for lower middle class south asian countries")
    matplotlib.pyplot.show()
    pass


if __name__ == '__main__':
    display_chart()
