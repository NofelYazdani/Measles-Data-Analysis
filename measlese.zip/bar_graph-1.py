import pandas
import matplotlib.pyplot


def gather_info(index):
    i = 1990
    temp = []
    year = []
    data = []
    read = pandas.read_csv("measles.csv")
    while i != 2020:
        data.append(read[str(i)][index])
        year.append(i)
        i = i + 3
    temp.append(data)
    temp.append(year)
    return temp


def display_bar():
    india = gather_info(78)
    pakistan = gather_info(129)
    canada = gather_info(31)
    usa = gather_info(185)
    df = pandas.DataFrame({"India": india[0], 'Pakistan': pakistan[0],
                           "Canada": canada[0], 'USA': usa[0]}, index=india[1])
    df.plot.barh()
    matplotlib.pyplot.xlabel("Vaccination percentage")
    matplotlib.pyplot.ylabel("Years")
    matplotlib.pyplot.title("Vaccination percentage LMI vs HI")
    matplotlib.pyplot.show()
    # read = pandas.read_csv("measles.csv")
    # print(read.pivot(index="Country", columns="World_Bank_Income_Level", values="1990" ))
    pass


if __name__ == '__main__':
    display_bar()
